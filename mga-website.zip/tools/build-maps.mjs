// Builds the two venue maps (The Shire London, Royal Greens KAEC) from OpenStreetMap
// data via the Overpass API and writes them as SVG files.
// Usage: node build-maps.mjs <outDir>
// Map data (c) OpenStreetMap contributors, ODbL.
import { writeFileSync, mkdirSync } from 'node:fs';

const OUT = process.argv[2] || 'maps';
const W = 600, H = 420;
const ENDPOINTS = [
  'https://overpass-api.de/api/interpreter',
  'https://overpass.kumi.systems/api/interpreter',
  'https://overpass.private.coffee/api/interpreter'
];

const COURSES = {
  shire: { id: 8044592, ids: [8044592], fit: [51.6600985, -0.2243251, 51.6715306, -0.2079725], pad: 0.12, query: [51.6560, -0.2300, 51.6755, -0.2022] },
  rg: { id: 305275716, ids: [305275716, 828144560], fit: [22.4394201, 39.0863697, 22.4575339, 39.0986715], pad: 0.15, query: [22.4285, 39.0790, 22.4684, 39.1060] }
};

async function overpass(bbox) {
  const b = bbox.join(',');
  const q = `[out:json][timeout:90];(way["golf"](${b});way["natural"~"water|coastline|beach|wood"](${b});way["water"](${b});way["highway"~"motorway|trunk|primary|secondary|tertiary|residential|unclassified|service"](${b});way["leisure"="golf_course"](${b}););out geom;`;
  for (let round = 0; round < 3; round++) {
    for (const ep of ENDPOINTS) {
      try {
        const r = await fetch(ep, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': 'gen1-mga-website-map-builder' },
          body: 'data=' + encodeURIComponent(q),
          signal: AbortSignal.timeout(120000)
        });
        const t = await r.text();
        if (t.trim().startsWith('{')) return JSON.parse(t);
        console.log(`  ${ep}: not JSON (status ${r.status})`);
      } catch (e) { console.log(`  ${ep}: ${e.message}`); }
    }
    await new Promise(r => setTimeout(r, 15000));
  }
  throw new Error('All Overpass endpoints failed');
}

function dp(pts, eps) {
  if (pts.length < 3) return pts;
  let dmax = 0, idx = 0;
  const a = pts[0], b = pts[pts.length - 1];
  const dx = b[0] - a[0], dy = b[1] - a[1], L = Math.hypot(dx, dy);
  for (let i = 1; i < pts.length - 1; i++) {
    const d = L < 1e-9 ? Math.hypot(pts[i][0] - a[0], pts[i][1] - a[1])
      : Math.abs(dy * pts[i][0] - dx * pts[i][1] + b[0] * a[1] - b[1] * a[0]) / L;
    if (d > dmax) { dmax = d; idx = i; }
  }
  if (dmax > eps) {
    const l = dp(pts.slice(0, idx + 1), eps), r = dp(pts.slice(idx), eps);
    return l.slice(0, -1).concat(r);
  }
  return [a, b];
}

function pip(p, poly) {
  let r = false;
  for (let i = 0, k = poly.length - 1; i < poly.length; k = i++) {
    const a = poly[i], b = poly[k];
    if (((a.lat > p.lat) !== (b.lat > p.lat)) && (p.lon < (b.lon - a.lon) * (p.lat - a.lat) / (b.lat - a.lat) + a.lon)) r = !r;
  }
  return r;
}

function build(j, c) {
  const [s, w, n, e] = c.fit;
  const lat0 = (s + n) / 2, cos = Math.cos(lat0 * Math.PI / 180);
  const bw = (e - w) * cos, bh = n - s;
  const k = Math.min(W / (bw * (1 + c.pad)), H / (bh * (1 + c.pad)));
  const cx = (w + e) / 2, cy = lat0;
  const P = g => g.map(p => [W / 2 + (p.lon - cx) * cos * k, H / 2 - (p.lat - cy) * k]);
  const inView = pts => pts.some(p => p[0] > -60 && p[0] < W + 60 && p[1] > -60 && p[1] < H + 60);
  const d = (pts, close, eps = 0.7) => {
    const sp = dp(pts, eps);
    if (sp.length < 2 || (close && sp.length < 3)) return '';
    return 'M' + sp.map(p => p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join('L') + (close ? 'Z' : '');
  };
  const L = { road: [], wood: [], water: [], fair: [], bunk: [], green: [], tee: [], course: [], coast: [] };
  const holes = [];
  const course = j.elements.find(x => x.id === c.id);
  if (!course || !course.geometry) throw new Error('Course outline not found for ' + c.id);
  for (const el of j.elements) {
    if (!el.geometry) continue;
    const t = el.tags || {};
    const pts = P(el.geometry);
    if (!inView(pts)) continue;
    const g = el.geometry;
    const closed = g.length > 3 && g[0].lat === g[g.length - 1].lat && g[0].lon === g[g.length - 1].lon;
    if (t.golf === 'hole') {
      if (pip(g[0], course.geometry)) holes.push({ ref: +t.ref, pts });
      continue;
    }
    let cls = null, eps = 0.7, cl = closed;
    if (t.highway) { cls = 'road'; eps = 1.2; cl = false; }
    else if (t.natural === 'wood') cls = 'wood';
    else if (t.natural === 'water' || t.water || /water_hazard/.test(t.golf || '')) cls = 'water';
    else if (t.natural === 'coastline') { cls = 'coast'; cl = false; }
    else if (t.golf === 'fairway') cls = 'fair';
    else if (t.golf === 'bunker') { cls = 'bunk'; eps = 0.4; }
    else if (t.golf === 'green') { cls = 'green'; eps = 0.4; }
    else if (t.golf === 'tee') cls = 'tee';
    else if (t.leisure === 'golf_course' && c.ids.includes(el.id)) cls = 'course';
    if (cls) { const v = d(pts, cl, eps); if (v) L[cls].push(v); }
  }
  holes.sort((a, b) => a.ref - b.ref);
  const gp = (cls, arr) => arr.length ? `<path class="${cls}" d="${arr.join('')}"/>` : '';
  let out = `<g class="map-base">${gp('m-wood', L.wood)}${gp('m-road', L.road)}${gp('m-water', L.water)}${gp('m-coast', L.coast)}${gp('m-fair', L.fair)}${gp('m-tee', L.tee)}${gp('m-bunk', L.bunk)}${gp('m-green', L.green)}</g>`;
  out += '<g class="map-route">';
  out += L.course.map(p => `<path class="m-course draw-line" pathLength="1" d="${p}"/>`).join('');
  out += holes.map((h, i) => {
    const b = h.pts[h.pts.length - 1];
    return `<path class="m-hole draw-line" pathLength="1" style="--i:${i}" d="${d(h.pts, false, 0.3)}"/><circle class="m-pin" style="--i:${i}" cx="${b[0].toFixed(1)}" cy="${b[1].toFixed(1)}" r="2.6"/>`;
  }).join('');
  if (holes.length) out += `<circle class="m-start" cx="${holes[0].pts[0][0].toFixed(1)}" cy="${holes[0].pts[0][1].toFixed(1)}" r="3.5"/>`;
  out += '</g>';
  console.log(`  holes: ${holes.length}, ` + Object.entries(L).map(([a, b]) => `${a}:${b.length}`).join(' '));
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><!-- Map data (c) OpenStreetMap contributors, ODbL --><g>${out}</g></svg>`;
}

mkdirSync(OUT, { recursive: true });
for (const [name, c] of Object.entries(COURSES)) {
  console.log('Building map: ' + name);
  const data = await overpass(c.query);
  const svg = build(data, c);
  writeFileSync(`${OUT}/map-${name}.svg`, svg);
  console.log(`  wrote ${OUT}/map-${name}.svg (${svg.length} bytes)`);
  await new Promise(r => setTimeout(r, 3000));
}
